#
#
#  14/10/2015
#  ol@staff.42.fr
#

MinilibX

Interface simplifiee de programmation graphique pour debutant
#

Cette minilibX est la version native pour MacOSX.
[ Elle n'utilise plus les librairies graphiques X11, ni XQuartz le serveur X pour MacOSX. ]
L'interface / l'API, reste identique a la version precedente. Les man presents dans la minilibX
d'origine sont toujours valides.

Le fichier mlx.h a inclure dans vos programmes rapelle les petites differences de comportement
entre les 2 versions, dues a la gestion graphique differente selon les systemes d'exploitation.

#

Cette version utilise le systeme de fenetrage Cocoa de MacOSX ( AppKit ), et les primitives
graphiques OpenGL moderne.

#

License: la MinilibX macos est fournie sous license BSD: Copyright Olivier Crouzet - 2014-2015
         la MinilibX est fournie sous license BSD:  Copyright Olivier Crouzet - 1999-2015
#
